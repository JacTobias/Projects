#include <stdio.h>

int main()
{
    printf("Hello yell!\n");
    return 0;
}